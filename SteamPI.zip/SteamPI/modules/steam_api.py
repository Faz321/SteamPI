import json
import requests
import time

API_KEY = "5A0D4B191D567190BEE11F6B57824F32"
print("-" * 26, "\n")
print("Steam Player Investigation\n")
print("-" * 26, "\n")

def safe_request(url, retries=3, delay=2):
    for attempt in range(retries):
        response = requests.get(url)
        if response.status_code == 429:
            print(f"Rate limited. Retrying ({attempt+1}/{retries}) in {delay} seconds...")
            time.sleep(delay)
        else:
            return response
    raise Exception(f"Failed request: {response.status_code} - {response.reason}")

def getApiCalls(steamID, isVanity=False):
    data = {}

    if isVanity:
        response = safe_request(
            f"http://api.steampowered.com/ISteamUser/ResolveVanityURL/v0001/?key={API_KEY}&vanityurl={steamID}"
        )
        try:
            jsonData = response.json()
        except json.JSONDecodeError:
            raise Exception("Failed to decode JSON from ResolveVanityURL response.")
        if jsonData["response"]["success"] == 1:
            steamID = jsonData["response"]["steamid"]
            print("The steamID is", steamID)
        else:
            raise Exception("SteamID not found")

    # Player summaries
    response = safe_request(
        f"http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key={API_KEY}&steamids={steamID}"
    )

    if not response.text.strip():
        raise Exception("Empty response received from GetPlayerSummaries")

    try:
        jsonData = response.json()
    except json.JSONDecodeError:
        print("Response text that failed to parse:\n", response.text)
        raise Exception("Failed to decode JSON from GetPlayerSummaries response.")

    players = jsonData.get("response", {}).get("players", [])
    if not players:
        raise Exception("No player data found. This might be due to an invalid SteamID or private profile.")

    player = players[0]
    userstate = player.get("personastate", 0)
    match userstate:
        case 0: print("Current Status: Offline")
        case 1: print("Current Status: Online")
        case 2: print("Current Status: Busy")
        case 3: print("Current Status: Away")
        case 4: print("Current Status: Snooze")
        case 5: print("Current Status: Looking to trade")
        case 6: print("Current Status: Looking to play")

    if player.get("realname"):
        data["Real Name"] = player["realname"]

    # Friend list
    response = safe_request(
        f"http://api.steampowered.com/ISteamUser/GetFriendList/v0001/?key={API_KEY}&steamid={steamID}&relationship=friend"
    )
    try:
        jsonData = response.json()
    except json.JSONDecodeError:
        raise Exception("Failed to decode JSON from GetFriendList response.")

    friends = jsonData.get("friendslist", {}).get("friends", [])
    data["Friends"] = len(friends)

    # Owned games
    response = safe_request(
        f"http://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key={API_KEY}&steamid={steamID}&format=json"
    )

    if not response.text.strip():
        raise Exception("Empty response received from GetOwnedGames")

    try:
        jsonData = response.json()
    except json.JSONDecodeError as e:
        print("Failed to parse response:", response.text)
        raise Exception("Failed to decode JSON from GetOwnedGames response.")

    gamesCount = jsonData.get("response", {}).get("game_count", 0)
    data["Games"] = gamesCount

    return data
