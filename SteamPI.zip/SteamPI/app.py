from flask import Flask, render_template, jsonify
from modules import calc, crawler, steam_api
from bs4 import BeautifulSoup

app = Flask(__name__)

@app.route("/")
def index():
    # Replace with your test SteamID or Vanity URL
    steam_id = "yourTestSteamID"  
    is_vanity = False  # Set to True if you're using a Vanity URL

    try:
        data = steam_api.getApiCalls(steam_id, is_vanity)
    except Exception as e:
        data = {"Error": str(e)}

    return render_template("index.html", api_data=data)

@app.route('/steam/<string:query>')
def steam_query(query):
    # Use the steam_api module to fetch data based on the query
    data = steam_api.get_steam_data(query)
    return jsonify(data)

@app.route('/calculate/<float:a>/<float:b>')
def calculator(a, b):
    # Use the calc module to perform calculation
    result = calc.calculate_values(a, b)
    return f"Calculation result: {result}"

@app.route('/crawl')
def crawler():
    # Use the crawler module to run the crawler
    result = crawler.run_crawler()
    return f"Crawler result: {result}"

if __name__ == '__main__':
    app.run(debug=True)
